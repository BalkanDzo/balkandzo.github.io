import xbmcgui
import xbmcplugin
import json
import urllib.request
import sys
import xbmcaddon
import urllib.parse
import xbmc
import resolveurl
import random

addon = xbmcaddon.Addon()

JSON_URL = addon.getSetting('json_url')

COUNTRIES_PER_PAGE = 15

def load_data_from_json():
    try:
        response = urllib.request.urlopen(JSON_URL)
        data = json.load(response)
        return data
    except Exception as e:
        xbmcgui.Dialog().ok('Greška', 'Greška u otvaranju liste. Provjerite vašu konekciju. Pokušajte ponovo.\n{}'.format(e))
        return None

def show_countries_list(page):
    data = load_data_from_json()
    if not data:
        return
    
    base_icon_url = 'http://balkandzo.byethost13.com/fomoti/' 

    countries = data['countries']

    start_index = (page - 1) * COUNTRIES_PER_PAGE
    end_index = page * COUNTRIES_PER_PAGE

    for country_index, country in enumerate(countries[start_index:end_index], start=start_index):
        list_item = xbmcgui.ListItem(label=country['country'])
        encoded_country_name = urllib.parse.quote(country['country'])
        icon_path = base_icon_url + encoded_country_name + '.jpg'  
        list_item.setArt({'icon': icon_path})
        url = '{0}?action=channels&country={1}'.format(sys.argv[0], encoded_country_name)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    if page > 1:
        list_item = xbmcgui.ListItem(label=f'[I][COLOR deepskyblue]-Prethodna Stranica- {page - 1}[/I][/COLOR]')
        url = '{0}?action=country&page={1}'.format(sys.argv[0], page - 1)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    list_item = xbmcgui.ListItem(label=f'[I][COLOR deepskyblue]-Pocetna Stranica-[/I][/COLOR]')
    url = '{0}?action=country&page=1'.format(sys.argv[0])
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    if end_index < len(countries):
        list_item = xbmcgui.ListItem(label=f'[I][COLOR deepskyblue]-Sledeca Stranica- {page + 1}[/I][/COLOR]')
        url = '{0}?action=country&page={1}'.format(sys.argv[0], page + 1)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    # Dodavanje opcije "Vrati se u Balkanteku"
    list_item = xbmcgui.ListItem(label=f'[I][COLOR deepskyblue]-Vrati se u Balkanteku-[/I][/COLOR]')
    url = 'plugin://plugin.video.balkanteka/'
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)


    # Dodajte opciju za pretragu
    list_item = xbmcgui.ListItem(label="[B]Pretraga[/B]")
    url = "{0}?action=search".format(sys.argv[0])
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_channels_list(country):
    data = load_data_from_json()
    if not data:
        return
    
    for channel in data['channels']:
        if country.lower() in channel['country'].lower():
            list_item = xbmcgui.ListItem(label=channel['channel'])
            list_item.setArt({'thumb': channel['logo']})  
            list_item.setInfo('video', {'title': channel['channel']})  
            
            id1 = channel.get('id1')
            id2 = channel.get('id2')
            id3 = channel.get('id3')
            
            url = '{0}?action=play&id1={1}&id2={2}&id3={3}'.format(sys.argv[0], id1, id2, id3)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def play_channel(id1, id2, id3):
    data = load_data_from_json()
    if not data:
        return

    urls = data['urls']

    qualities = []
    if id1:
        qualities.append('Stream 1')
    if id2:
        qualities.append('Stream 2')
    if id3:
        qualities.append('Stream 3')

    dialog = xbmcgui.Dialog()
    index = dialog.select('Izaberite Stream:', qualities)

    if index == -1:
        return  

    selected_quality = qualities[index]

    if selected_quality == 'Stream 1':
        url_group = 'urls1'
        chosen_id = id1
    elif selected_quality == 'Stream 2':
        url_group = 'urls2'
        chosen_id = id2
    elif selected_quality == 'Stream 3':
        url_group = 'urls3'
        chosen_id = id3

    if chosen_id is None:
        xbmcgui.Dialog().ok('Greška', 'Nijedan stream link nije pronadjen.')
        return

    url = random.choice(urls[url_group])

    channel_url = url + chosen_id

    logo = ''
    channel_name = ''

    for channel in data['channels']:
        if (url_group == 'urls1' and channel['id1'] == chosen_id) or \
           (url_group == 'urls2' and channel['id2'] == chosen_id) or \
           (url_group == 'urls3' and channel['id3'] == chosen_id):
            channel_name = channel['channel']
            logo = channel['logo']
            break

    if not channel_name:
        xbmcgui.Dialog().ok('Greška', 'Izabrani film nije pronađen.')
        return

    list_item = xbmcgui.ListItem(channel_name)
    list_item.setArt({'thumb': logo})
    list_item.setInfo('video', {'title': channel_name})

    # Koristi resolveurl za sve kvalitete
    playable_url = resolveurl.resolve(channel_url)
    if playable_url:
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)
        xbmc.Player().play(playable_url, listitem=list_item)
    else:
        xbmcgui.Dialog().ok('Greška', 'Izabrani stream link ne radi. Pokrenite ponovo sadržaj da se izabere novi stream link.')


def search(query):
    data = load_data_from_json()
    if not data:
        return

    base_icon_url = 'https://kodibalkan.com/fomoti/'

    results = []
    for country in data['countries']:
        country_name = country['country'].lower()

        if query.lower() in country_name:
            results.append({'type': 'country', 'data': country})
        
        for channel in data['channels']:
            channel_name = channel['channel'].lower()
            
            if query.lower() in channel_name and country['country'] == channel['country']:
                results.append({'type': 'channel', 'data': channel})

    for result in results:
        if result['type'] == 'country':
            list_item = xbmcgui.ListItem(label=result['data']['country'])
            encoded_country_name = urllib.parse.quote(result['data']['country'])
            icon_path = base_icon_url + encoded_country_name + '.jpg'  
            list_item.setArt({'icon': icon_path})
            url = '{0}?action=channels&country={1}'.format(sys.argv[0], encoded_country_name)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)
        elif result['type'] == 'channel':
            list_item = xbmcgui.ListItem(label=result['data']['channel'])
            list_item.setArt({'thumb': result['data']['logo']})  
            list_item.setInfo('video', {'title': result['data']['channel']})  
            
            id1 = result['data'].get('id1')
            id2 = result['data'].get('id2')
            id3 = result['data'].get('id3')
            
            url = '{0}?action=play&id1={1}&id2={2}&id3={3}'.format(sys.argv[0], id1, id2, id3)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def run_addon():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].replace('?', '')))
    action = params.get('action', None)
    
    if action is None:
        show_countries_list(page=1)
    elif action == 'country':
        page = int(params.get('page', 1))
        show_countries_list(page)
    elif action == 'channels':
        country = params['country']
        show_channels_list(country)
    elif action == 'play':
        id1 = params.get('id1')
        id2 = params.get('id2')
        id3 = params.get('id3')
        play_channel(id1, id2, id3)
    elif action == 'search':
        query = xbmcgui.Dialog().input('Unesite ključnu reč za pretragu zemlje')
        if query:
            search(query)

if __name__ == '__main__':
    run_addon()
