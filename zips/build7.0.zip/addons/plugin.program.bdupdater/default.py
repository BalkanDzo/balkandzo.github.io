import os
import urllib.request
import zipfile
import xbmc
import xbmcgui
import xbmcvfs
import sys
import time

# Kodi addons folder path
ADDONS_FOLDER = xbmcvfs.translatePath('special://home/')

def check_url_available(url):
    """
    Proverava da li je URL dostupan.
    Vraća True ako je dostupan, inače False.
    """
    try:
        request = urllib.request.Request(url, method='HEAD')
        response = urllib.request.urlopen(request)
        return response.status == 200
    except Exception as e:
        xbmc.log(f"URL check error: {str(e)}", xbmc.LOGERROR)
        return False

def download_and_extract_zip(url, destination_folder):
    zip_path = os.path.join(destination_folder, 'updates.zip')

    try:
        xbmcgui.Dialog().notification("Preuzimanje", "Preuzimanje dodatka je u toku...", xbmcgui.NOTIFICATION_INFO, 5000)
        
        with urllib.request.urlopen(url) as response:
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(zip_path, 'wb') as f:
                while chunk := response.read(1024):
                    f.write(chunk)
                    downloaded += len(chunk)
                    percent = (downloaded / total_size) * 100
                    xbmc.log(f"Downloaded: {percent:.2f}%")

        xbmcgui.Dialog().notification("Preuzimanje", "Preuzimanje završeno.", xbmcgui.NOTIFICATION_INFO, 3000)

        xbmcgui.Dialog().notification("Ekstrakcija", "Ekstrakcija dodatka je u toku...", xbmcgui.NOTIFICATION_INFO, 5000)
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(destination_folder)
        xbmcgui.Dialog().notification("Ekstrakcija", "Ekstrakcija završena.", xbmcgui.NOTIFICATION_INFO, 3000)

        os.remove(zip_path)

        time.sleep(10)

        xbmcgui.Dialog().ok('Restartovanje Kodija', f'Potrebno pokrenuti ponovo kodi da bi se dodaci ažurirali.')

        if os.name == 'nt':
            os.system('taskkill /IM kodi.exe /F')
            sys.exit(0)
        else:  # Za Linux
            xbmc.executebuiltin('Quit()')

    except Exception as e:
        xbmcgui.Dialog().notification("Greška", f"Greška prilikom instalacije: {str(e)}", xbmcgui.NOTIFICATION_ERROR, 5000)

if __name__ == '__main__':
    ZIP_URL = 'https://github.com/BalkanDzo/balkandzo.github.io/raw/refs/heads/main/zips/updates.zip'

    if check_url_available(ZIP_URL):
        download_and_extract_zip(ZIP_URL, ADDONS_FOLDER)
    else:
        xbmcgui.Dialog().notification("Obaveštenje", "Nema dostupnih dodataka za instalaciju.", xbmcgui.NOTIFICATION_INFO, 5000)
