import xbmcgui
import xbmcplugin
import json
import urllib.request
import sys
import xbmcaddon
import urllib.parse
import random
import xbmc
import time

# Balkan Dzo Addon by Dzon Dzoe

addon = xbmcaddon.Addon()
JSON_URL = addon.getSetting('json_url')

def load_data_from_json():
    try:
        response = urllib.request.urlopen(JSON_URL)
        data = json.load(response)
        return data
    except Exception as e:
        xbmcgui.Dialog().ok('Greška', 'Greška u otvaranju liste. Provjerite vašu konekciju. Pokušajte ponovo.\n{}'.format(e))
        return None

def test_url(url):
    """Proverava da li URL radi."""
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(request) as response:
            return response.status == 200
    except:
        return False

def get_channel_info(data, url_group, chosen_id):
    """Vraća informacije o kanalu na osnovu ID-a."""
    for channel in data['channels']:
        if (url_group == 'urls1' and channel['id1'] == chosen_id) or \
           (url_group == 'urls2' and channel['id2'] == chosen_id) or \
           (url_group == 'urls3' and channel['id3'] == chosen_id):
            return channel['channel'], channel['logo']
    return None, None

def show_countries_list():
    data = load_data_from_json()
    if not data:
        return

    base_icon_url = 'http://balkandzo.byethost13.com/fomoti/'

    for country in data['countries']:
        list_item = xbmcgui.ListItem(label=country['country'])
        encoded_country_name = urllib.parse.quote(country['country'])
        icon_path = base_icon_url + encoded_country_name + '.jpg'
        list_item.setArt({'icon': icon_path})
        url = '{0}?action=channels&country={1}'.format(sys.argv[0], encoded_country_name)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_channels_list(country):
    data = load_data_from_json()
    if not data:
        return

    for channel in data['channels']:
        if channel['country'] == country:
            list_item = xbmcgui.ListItem(label=channel['channel'])
            list_item.setArt({'thumb': channel['logo']})
            list_item.setInfo('video', {'title': channel['channel']})

            id1 = channel.get('id1')
            id2 = channel.get('id2')
            id3 = channel.get('id3')

            url = '{0}?action=play&id1={1}&id2={2}&id3={3}'.format(sys.argv[0], id1, id2, id3)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_channel(id1, id2, id3):
    data = load_data_from_json()
    if not data:
        return

    urls = data['urls']

    qualities = []
    if id1:
        qualities.append(('urls1', id1))
    if id2:
        qualities.append(('urls2', id2))
    if id3:
        qualities.append(('urls3', id3))

    dialog = xbmcgui.Dialog()
    index = dialog.select('Izaberite Stream:', [f'Stream {i+1}' for i in range(len(qualities))])

    if index == -1:
        return  # User canceled

    url_group, chosen_id = qualities[index]

    if not urls[url_group]:
        xbmcgui.Dialog().ok('Greška', 'Nema dostupnih URL-ova za izabrani stream.')
        return

    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create('Provera streamova', 'Molimo sačekajte...')

    start_time = time.time()

    for i, url in enumerate(random.sample(urls[url_group], len(urls[url_group]))):  # Shuffle and iterate
        if time.time() - start_time > 20:
            progress_dialog.close()
            xbmcgui.Dialog().ok('Greška', 'Provera je trajala predugo. Pokušajte ponovo.')
            return

        if progress_dialog.iscanceled():
            progress_dialog.close()
            return  # User canceled the process

        progress_dialog.update(
            int((i + 1) / len(urls[url_group]) * 100),
            f'Proveravam listu {i + 1}'
        )

        full_url = url + chosen_id
        if test_url(full_url):
            progress_dialog.close()

            channel_name, logo = get_channel_info(data, url_group, chosen_id)
            if not channel_name:
                xbmcgui.Dialog().ok('Greška', 'Izabrani film nije pronađen.')
                return

            list_item = xbmcgui.ListItem(channel_name)
            list_item.setArt({'thumb': logo})
            list_item.setInfo('video', {'title': channel_name})

            try:
                xbmc.Player().play(full_url, listitem=list_item)
                return  # Successfully playing
            except Exception as e:
                xbmc.log(f"Greška prilikom reprodukcije: {e}", level=xbmc.LOGERROR)

    progress_dialog.close()
    xbmcgui.Dialog().ok('Greška', 'Nijedan stream nije uspešno pokrenut. Pokušajte ponovo.')

def run_addon():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].replace('?', '')))
    action = params.get('action', None)

    if action is None:
        show_countries_list()
    elif action == 'channels':
        country = params['country']
        show_channels_list(country)
    elif action == 'play':
        id1 = params.get('id1')
        id2 = params.get('id2')
        id3 = params.get('id3')
        play_channel(id1, id2, id3)

if __name__ == '__main__':
    run_addon()
