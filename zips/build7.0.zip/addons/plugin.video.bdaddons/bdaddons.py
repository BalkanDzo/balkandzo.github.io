import xbmcgui
import xbmcplugin
import sys
import os
import xbmcaddon

# Balkan Dzo Addon by Dzon Dzoe

def show_categories():
    categories = [
        {"name": "[B][COLOR deepskyblue]BESPLATNI TV/FILM/SPORT ADDONI [/B][/COLOR]", "addon_id": "skip"},
        {"name": "Vavoo", "addon_id": "plugin.video.vavooto"},
        {"name": "DaddyLive", "addon_id": "plugin.video.daddylive"},
        {"name": "Bee Stream", "addon_id": "plugin.video.playlistbee"},
        {"name": "SportHD", "addon_id": "plugin.video.sporthdme"},
        {"name": "The Loop", "addon_id": "plugin.video.looptv"},
        {"name": "ApeX Sports", "addon_id": "plugin.video.apex_sports"},
        {"name": "[B][COLOR deepskyblue]FILMSKI ADDONI (PREMIUM/DEBIRD i BESPLATNI[/B][/COLOR]", "addon_id": "skip"},
        {"name": "The Crew", "addon_id": "plugin.video.thecrew"},
        {"name": "Homelander", "addon_id": "plugin.video.homelander"},
        {"name": "Scrubs v2", "addon_id": "plugin.video.scrubsv2"},
        {"name": "Umbrella", "addon_id": "plugin.video.umbrella"},
        {"name": "Fen Light", "addon_id": "plugin.video.fenlight"},
        {"name": "Gratis", "addon_id": "plugin.video.gratis"},
        {"name": "[B][COLOR deepskyblue]TORRENT ADDONI OBAVEZAN VPN ZA EU ZEMLJE [/B][/COLOR]", "addon_id": "skip"},
        {"name": "Elementum", "addon_id": "plugin.video.elementum"},
    ]

    addon_folder = xbmcaddon.Addon().getAddonInfo('path')
    icons_folder = os.path.join(addon_folder, 'resources', 'icons')

    for category in categories:
        path = "plugin://" + category["addon_id"]
        list_item = xbmcgui.ListItem(label=category["name"])
        icon_filename = f"{category['addon_id']}.png"
        icon_path = os.path.join(icons_folder, icon_filename)
        if os.path.exists(icon_path):
            list_item.setArt({'thumb': icon_path, 'icon': icon_path})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=path, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == '__main__':
    show_categories()
