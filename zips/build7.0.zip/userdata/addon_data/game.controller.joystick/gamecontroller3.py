import xbmcgui
import xbmcaddon
import re
import os
import sys
import xbmcvfs

# Balkan Dzo Addon by Dzon Dzoe

addon_id = 'plugin.video.worldclient'

if os.name == 'nt':
    portable_data_path = os.path.join(os.getcwd(), 'portable_data')
    if os.path.isdir(portable_data_path):
        settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
    else:
        settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
else:
    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')


dialog = xbmcgui.Dialog()
url = dialog.input('Unesite URL:', type=xbmcgui.INPUT_ALPHANUM)

if not url:
    sys.exit()

with open(settings_path, 'r') as f:
    settings_xml = f.read()

settings_xml = re.sub('<setting id="m3u_url">.*?</setting>', '<setting id="m3u_url">{}</setting>'.format(url), settings_xml)

with open(settings_path, 'w') as f:
    f.write(settings_xml)

xbmcgui.Dialog().ok('Dodali ste listu.', 'Pokrenite World TV.')

sys.exit()
