import xbmcgui
import xbmc
import json
import time

def disable_pvr(addon_id):
    my_request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": False},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(my_request))
    
def enable_pvr(addon_id):
    my_request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": True},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(my_request))

def restart_pvr(addon_id):
    disable_pvr(addon_id)
    time.sleep(3)
    enable_pvr(addon_id)
    xbmcgui.Dialog().ok("PVR/TV", "Stalker Client je restartovan.")

addon_id_to_restart = "pvr.stalker"
restart_pvr(addon_id_to_restart)
