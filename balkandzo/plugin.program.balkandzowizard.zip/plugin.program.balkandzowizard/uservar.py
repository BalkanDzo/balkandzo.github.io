import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://bandateam.ucoz.com/wizard/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://bandateam.ucoz.com/wizard/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
