# -*- coding: utf-8 -*-
import xbmcgui, xbmcplugin, xbmcaddon, xbmc
import sys, json, urllib.request, ssl, random, time, os
from urllib.parse import urlencode, parse_qsl, quote

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
ADDON_PATH = ADDON.getAddonInfo('path') 

SERVER_URL = ADDON.getSetting('server_url')
if not SERVER_URL.endswith('/'):
    SERVER_URL += '/'

USER_AGENT = ADDON.getSetting('playback_user_agent') or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

ICON_DIR = os.path.join(ADDON_PATH, 'resources', 'icons')

CATEGORIES = [
    {"name": "BOSNA I HERCEGOVINA", "file": "bosna_kanali.json", "icon": "bosna.png"},
    {"name": "CRNA GORA", "file": "crnagora_kanali.json", "icon": "crnagora.png"},
    {"name": "DJEČIJI KANALI", "file": "djeciji_kanali.json", "icon": "kids.png"},
    {"name": "DOKUMENTARNI KANALI", "file": "dokumentarni_kanali.json", "icon": "dokumentarni.png"},
    {"name": "FILMOVI I SERIJE", "file": "filmovi_kanali.json", "icon": "filmovi.png"},
    {"name": "HRVATSKA", "file": "hrvatska_kanali.json", "icon": "hrvatska.png"},
    {"name": "LIFESTYLE", "file": "lifestyle_kanali.json", "icon": "lifestyle.png"},
    {"name": "MAKEDONIJA", "file": "makedonija_kanali.json", "icon": "makedonija.png"},
    {"name": "MUZIKA", "file": "muzika_kanali.json", "icon": "muzika.png"},
    {"name": "PINK PAKET", "file": "pinktv_kanali.json", "icon": "pink.png"},
    {"name": "SLOVENIJA", "file": "slovenija_kanali.json", "icon": "slovenija.png"},
    {"name": "SPORT", "file": "sporttv_kanali.json", "icon": "sport.png"},
    {"name": "SRBIJA", "file": "srbija_kanali.json", "icon": "srbija.png"}
]

def show_categories():
    sorted_cats = sorted(CATEGORIES, key=lambda k: k['name'])
    
    for cat in sorted_cats:
        li = xbmcgui.ListItem(label=cat['name'])
        
        local_icon = os.path.join(ICON_DIR, cat['icon'])
        if not os.path.exists(local_icon):
            local_icon = "DefaultFolder.png"
        li.setArt({'icon': local_icon, 'thumb': local_icon})
        
        full_url = SERVER_URL + cat['file']
        
        params = {'action': 'list_channels', 'url': full_url}
        url = f"{sys.argv[0]}?{urlencode(params)}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_channels(json_url):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        context = ssl._create_unverified_context()
        req = urllib.request.Request(json_url, headers={'User-Agent': USER_AGENT})
        with urllib.request.urlopen(req, context=context) as response:
            data = json.loads(response.read().decode('utf-8'))
        
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        channels = data.get('channels', [])
        channels = sorted(channels, key=lambda k: k.get('name', '').lower())
        
        for ch in channels:
            name, logo, streams = ch.get('name'), ch.get('logo'), ch.get('streams', [])
            if not streams: continue
            
            li = xbmcgui.ListItem(label=name)
            li.setArt({'thumb': logo, 'icon': logo})
            li.getVideoInfoTag().setTitle(name)
            li.setProperty('IsPlayable', 'true')
            
            params = {'action': 'play', 'url': "|".join(streams), 'name': name}
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{sys.argv[0]}?{urlencode(params)}", listitem=li)
    except: 
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().ok("Greška", f"Ne mogu učitati listu:\n{json_url}")
    
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def check_link_fast(url):
    try:
        context = ssl._create_unverified_context()
        req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
        req.get_method = lambda: 'HEAD'
        with urllib.request.urlopen(req, context=context, timeout=5) as resp:
            return resp.getcode() == 200
    except: return False

def play_video(streams_str, channel_name):
    streams = streams_str.split("|")
    random.shuffle(streams)
    
    total = len(streams)
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('Balkan IPTV Pretraga', f'Kanal: {channel_name}')
    
    working_url = None
    for i, url in enumerate(streams):
        if p_dialog.iscanceled(): break
        curr = i + 1
        percent = int((curr / total) * 100)
        
        msg = f"Dostupno izvora: {total}\nProvjeravam izvor {curr}...\nStatus: Testiranje brzine servera"
        p_dialog.update(percent, msg)
        
        if check_link_fast(url):
            working_url = url
            break
            
    p_dialog.close()
    
    if working_url:
        full_path = working_url + "|User-Agent=" + quote(USER_AGENT)
        li = xbmcgui.ListItem(path=full_path)
        
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setContentLookup(False)
        li.setMimeType('application/vnd.apple.mpegurl')
        # --------------------------------------
        
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)
    else:
        xbmcgui.Dialog().notification('Greška', 'Nijedan izvor trenutno ne radi.', xbmcgui.NOTIFICATION_ERROR, 3000)

params = dict(parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if not action:
    show_categories()
elif action == 'list_channels':
    list_channels(params.get('url'))
elif action == 'play':
    play_video(params.get('url'), params.get('name', 'Kanal'))